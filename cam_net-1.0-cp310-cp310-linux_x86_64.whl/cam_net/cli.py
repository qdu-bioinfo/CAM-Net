# cam_net/cli.py
from pathlib import Path
import typer
from cam_net.pipeline import run_pipeline

app = typer.Typer(
    help="CAM-Net: Context-aware microbial correlation analysis"
    # ,add_completion=False,
)

@app.command("run")
def run_analysis(
    input_csv: Path = typer.Option(
        ...,
        "--input",
        help="CSV file path",
        exists=True,
        dir_okay=False,
    ),
    seed: str = typer.Option(
        ...,
        "--target",
        help="target microbe e.g., g__Lactobacillus",
    ),
    output: Path = typer.Option(
        Path("results"),
        "--output",
        help="output directory",
    ),

):
    typer.secho("\n")
    typer.echo(f"{typer.style('Run CAM-Net | target microbe: ', bold=True)}{seed}{typer.style(' | input: ', bold=True)}{input_csv.name}")
    typer.echo(f"{typer.style('Output directory:', bold=True)} {output.resolve()}")

    result_df = run_pipeline(
        csv_path=input_csv,
        seed_taxa=seed,
        output_dir=output,

    )

    if result_df is None or result_df.empty:
        typer.secho("Analysis failed: No effective optimal consortium containing the target microbe was found.", fg=typer.colors.RED)
        raise typer.Exit(code=1)


    row = result_df.iloc[0]

    typer.echo(f"{typer.style('Threshold:', bold=True)} {row['Threshold']:.6f} (the top 1%, based on 10000 random pairs)")

    typer.secho("\n")
    typer.secho("═" * 70, fg=typer.colors.GREEN)
    typer.secho("\n")

    # 注意这里用的是 typer.echo
    typer.echo(f"{typer.style('Target microbe:', bold=True)} {row['Seed_Taxon']}")
    typer.echo(f"{typer.style('Members of the optimal consortium:', bold=True)} {row['Clique_Members']}")
    typer.echo(f"{typer.style('The size of optimal consortium:', bold=True)} {row['Clique_Size']}")
    typer.echo(f"{typer.style('Predicted R value:', bold=True)} {row['r-value']:.4f}")

    typer.secho("\n")
    typer.secho("═" * 70, fg=typer.colors.GREEN, bold=True)
    typer.secho("\n")

    typer.secho("\nDetailed results have been saved:", bold=True)
    typer.secho(f"  • {output / 'predictions.csv'}      → All sample actual vs. predicted abundance")
    typer.secho(f"  • {output / 'prediction_plot.pdf'}  → Scatter plot and predicted R value")
    typer.secho(f"  • {output / 'summary.csv'}          → Summarize the information (target microbe, optimal consortium, R value)")
    typer.secho(f"  • {output / 'edges.csv'}            → Network edge list")


if __name__ == "__main__":
    app()